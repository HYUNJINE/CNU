
$("button").click(function(){
        var data = {title:$("#title").val(),content:$("#content").val()};
        var jsondata = JSON.stringify(data);
        
        alert(jsondata); 
        $.post("abc.php",
        {
        //title: $("#title").text(),
        //content: $("#content").text()
        data:jsondata
        },
        function(data){
        alert("저장되었습니다.");
        // console.log(data);
        });
});


$("#keyword").change(function(){
    var data = {key:$("#keyword").val()}
    var jsonkeyword = JSON.stringify(data);
    alert(jsonkeyword);
   
    $.post("abcd.php",
    {
        data1:jsonkeyword
    },
    function(data){
        alert(data);
        // console.log(data);
        // console.log(typeof data);
        var parsedata = JSON.parse(data);
        // console.log(parsedata);
        
        // final = makelist(parsedata);
        list=""
        for(var i = 0; i    <parsedata.length; i++) {
            list += "<li>"+parsedata[i]+"</li>";
        }
        $("#title_list").html(list);
        
    });
 
})

