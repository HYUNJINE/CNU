<?php
// $title = $_POST("title");
// $content = $_POST("content");
$data = $_POST["data"];
$validation_data = test_input($data);
$file =fopen("data.json","a+");
$write = fwrite($file,$validation_data.PHP_EOL);
echo $validation_data;


function test_input($data) {
    $data = trim($data);
    // $data = stripslashes($data);
    // $data = htmlspecialchars($data);
    return $data;
  }
?>


