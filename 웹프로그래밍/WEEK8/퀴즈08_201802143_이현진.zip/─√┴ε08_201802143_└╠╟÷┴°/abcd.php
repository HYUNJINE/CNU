<?php
$data=$_POST["data1"];
// $decode_keyword = json_decode($keyword);
// $file =fopen("dataa.json","a+");
// $write = fwrite($file,$decode_keyword->key);
$jsondata = json_decode($data);
$word = $jsondata->key;

$file = file_get_contents("data.json");
$explodefile = explode("\n", $file, -1);
// print_r($explodefile);
// echo count($explodefile);
// $b= json_decode($explodefile[0],true);
// print_r(json_decode($explodefile[0],true));
// echo $b["title"];
$title= array();
for ($i=0; $i < count($explodefile); $i++) {
    $a = json_decode($explodefile[$i],true);
    // echo $a["title"];
    array_push($title, $a["title"]);
}
$print_title = array();
for($i=0; $i < count($title); $i++) {
    if(stristr($title[$i],$word)) {
        array_push($print_title,$title[$i]);
    }
}
$json_print_title = json_encode($print_title);
// $write = fwrite($file,$data.PHP_EOL);

echo $json_print_title;
// echo $jsondata->key;
// echo $data;

?>

