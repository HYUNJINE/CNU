<!DOCTYPE html>
<html>
<body>
<h2>숫자 맞추기 게임</h2>
당신이 생각한 숫자를 컴퓨터가 맞추는 게임입니다.<br><br>

<?php
$userNumber = ;                   // 당신이 생각하는 숫자를 넣으시오.

function numgame() {

}
?>
</body>
</html>
